test.AddQuestion(
    new Question (
        GolfExample.CourseActivity.id + "/GolfAssessment/interactions.fun_1",
        "To make friends on the golf course, you should play really slowly.",
        QUESTION_TYPE_TF,
        null,
        false,
        "obj_havingfun"
    )
);

test.AddQuestion(
    new Question (
        GolfExample.CourseActivity.id + "/GolfAssessment/interactions.fun_2",
        "Knickers indicate a refined sense of style.",
        QUESTION_TYPE_TF,
        null,
        false,
        "obj_havingfun"
    )
);

test.AddQuestion(
    new Question (
        GolfExample.CourseActivity.id + "/GolfAssessment/interactions.fun_3",
        "You should take your score very seriously if you want to have a lot of fun on the course.",
        QUESTION_TYPE_TF,
        null,
        false,
        "obj_havingfun"
    )
);
